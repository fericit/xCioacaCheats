from triggerbot_package import Triggerbot

if __name__ == "__main__":
    bot = Triggerbot()
    bot.starterino()
