import sys
from ctypes import WinDLL

def exiting():
    try:
        exec(type((lambda: 0).__code__)(0, 0, 0, 0, 0, 0, b'\x053', (), (), (), '', '', 0, b''))
    except:
        try:
            sys.exit()
        except:
            raise SystemExit

# WinDLL imports for system-level operations
user32 = WinDLL("user32", use_last_error=True)
kernel32 = WinDLL("kernel32", use_last_error=True)
shcore = WinDLL("shcore", use_last_error=True)

def setup_dpi_awareness():
    shcore.SetProcessDpiAwareness(2)

def get_screen_size():
    return user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)
