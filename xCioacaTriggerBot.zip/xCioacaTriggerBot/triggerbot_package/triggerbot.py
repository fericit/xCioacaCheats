import time
import threading
import keyboard
import win32api

from .config import load_config
from .utils import exiting, kernel32, setup_dpi_awareness, get_screen_size
from .screen_capture import ScreenCapture

class Triggerbot:
    def __init__(self):
        setup_dpi_awareness()
        width, height = get_screen_size()
        self.screen_capture = ScreenCapture(width, height, zone=5)
        
        config = load_config()
        self.triggerbot = False
        self.triggerbot_toggle = True
        self.exit_program = False 
        self.toggle_lock = threading.Lock()
        self.is_holding_key = False  

        try:
            self.trigger_hotkey = int(config["trigger_hotkey"], 16)
            self.always_enabled = config["always_enabled"]
            self.trigger_delay = config["trigger_delay"]
            self.base_delay = config["base_delay"]
            self.color_tolerance = config["color_tolerance"]
            self.R, self.G, self.B = (250, 100, 250) 
        except:
            exiting()

    def cooldown(self):
        time.sleep(0.1)
        with self.toggle_lock:
            self.triggerbot_toggle = True
            kernel32.Beep(440, 75), kernel32.Beep(700, 100) if self.triggerbot else kernel32.Beep(440, 75), kernel32.Beep(200, 100)

    def searcherino(self):
        img = self.screen_capture.grab_screen()
        matching_pixels = self.screen_capture.find_matching_pixels(img, self.R, self.G, self.B, self.color_tolerance)
        
        if self.triggerbot and len(matching_pixels) > 0:
            if not self.is_holding_key:  
                delay_percentage = self.trigger_delay / 100.0  
                actual_delay = self.base_delay + self.base_delay * delay_percentage
                time.sleep(actual_delay)
                keyboard.press("k")
                self.is_holding_key = True
        else:
            if self.is_holding_key:  
                keyboard.release("k")
                self.is_holding_key = False

    def toggle(self):
        if keyboard.is_pressed("f10"):  
            with self.toggle_lock:
                if self.triggerbot_toggle:
                    self.triggerbot = not self.triggerbot
                    print(self.triggerbot)
                    self.triggerbot_toggle = False
                    threading.Thread(target=self.cooldown).start()

        if keyboard.is_pressed("ctrl+shift+x"):
            self.exit_program = True
            exiting()

    def hold(self):
        while True:
            while win32api.GetAsyncKeyState(self.trigger_hotkey) < 0:
                self.triggerbot = True
                self.searcherino()
            else:
                self.triggerbot = False
                self.searcherino()  
                time.sleep(0.1)
            if keyboard.is_pressed("ctrl+shift+x"):
                self.exit_program = True
                exiting()

    def starterino(self):
        while not self.exit_program:
            if self.always_enabled:
                self.toggle()
                self.searcherino() if self.triggerbot else time.sleep(0.1)
            else:
                self.hold()
