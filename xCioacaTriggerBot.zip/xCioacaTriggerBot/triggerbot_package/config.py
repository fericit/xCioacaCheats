import json

def load_config(config_file='config.json'):
    with open(config_file) as json_file:
        return json.load(json_file)
