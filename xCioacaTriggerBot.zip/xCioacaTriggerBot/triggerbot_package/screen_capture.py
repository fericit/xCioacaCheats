import numpy as np
from mss import mss as mss_module

class ScreenCapture:
    def __init__(self, width, height, zone):
        self.sct = mss_module()
        self.grab_zone = (
            int(width / 2 - zone),
            int(height / 2 - zone),
            int(width / 2 + zone),
            int(height / 2 + zone),
        )

    def grab_screen(self):
        return np.array(self.sct.grab(self.grab_zone))

    def find_matching_pixels(self, img, r, g, b, tolerance):
        pixels = img.reshape(-1, 4)
        color_mask = (
            (pixels[:, 0] > r - tolerance) & (pixels[:, 0] < r + tolerance) &
            (pixels[:, 1] > g - tolerance) & (pixels[:, 1] < g + tolerance) &
            (pixels[:, 2] > b - tolerance) & (pixels[:, 2] < b + tolerance)
        )
        return pixels[color_mask]
