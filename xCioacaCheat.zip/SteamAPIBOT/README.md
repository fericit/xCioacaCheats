# Fast-Valorant-Triggerbot
By far the fastest available python triggerbot out there, no joke its speed is pretty crazy.

# About it
Reaction time is equivalent to your refresh rate, during testing I measured around 2-10ms reaction time,
which is extremely fast for a python triggerbot. This Triggerbot can be used with any hotkey you'd like,
just go into config.json and replace trigger_hotkey with any virtual key code, you can find them here: https://learn.microsoft.com/en-us/windows/win32/inputdev/virtual-key-codes


# How to setup
- If you you're a coder, you can use the source, if not please proceed to use the exe.
- Start Exe, Start Valorant, go to ingame settings and use purple outline.
- While being in ingame settings go to keybinds and add K as a second shoot keybind.
- By default  shift is the hotkey, if you have always enabled turn on, use f10 instead.
- Should work

- Additionally you can change the color tolerance, I recommend 20-70, also a delay can be added, => config.json

Exe is not provided in the github repo but is still downloadable through unknowncheats
https://www.unknowncheats.me/forum/valorant/612762-fastest-python-valorant-triggerbot-fr.html
https://www.unknowncheats.me/forum/downloads.php?do=file&id=42887

# Preview
[![Watch the video](https://cdn-cf-east.streamable.com/image/dizst6_first.jpg?Expires=1701277944784&Key-Pair-Id=APKAIEYUVEN4EVB2OKEQ&Signature=m7tTmO3eSM1uds8b-9OpFJm5x~2Jb0t2WfSKwFOLz0q5ofl7bGJ6ww5wBfx44~mtZxFjc9PsUeCV6JtXz5OFFCfutKuTWUQbkuqsMGVbI2bMQNsEuoYhBKig2O0MJNCnPWgpWHEpUoB3GikaHcYCvG~I-0y7p5PP2DvwgN~Px5IgZs84VPx-qyuFav8c255sm41rjg87aiRNQiObxaaBN3EKpuYFmBVB8~jb863EhJzRIPXkYJEgZRIbeBHJGEDtM-wH4gjSyuzuB4KgeX3Q0KOsOZwH6xkknwOm0SwXHnYiFzfPQRvbfV1l89XPRZu7LvXLAhD3BdFLTdh5ktr57A)](https://streamable.com/dizst6)

# FAQ
Can I get banned using this?
- there is always a risk but its very unlikely, i'd recommend compiling the source by yourself though and maybe adding vmp to it

How to make it faster?
- this is already pretty fast but if you'd wish to make it faster you can add DXCAM to it and maybe multithreading, these are the only ways I can think of to make it even faster, additionally this in any native language would be a lot faster already.

Why release this?
- why not


PS: Exe is compiled with nuitka!!!
