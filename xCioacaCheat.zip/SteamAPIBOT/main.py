import json
import time
import threading
import keyboard
import sys
import win32api
from ctypes import WinDLL
import numpy as np
from mss import mss

# Constants
EXIT_HOTKEY = "ctrl+shift+x"  # Key combination to exit the program
TOGGLE_HOTKEY = "f10"  # Key to toggle the triggerbot on and off
DEFAULT_COLOR = (250, 100, 250)  # Default RGB color to detect (purple)
COOLDOWN_TIME = 0.05  # Reduced cooldown between toggles for faster response

# Load DLLs for system calls
user32 = WinDLL("user32", use_last_error=True)
kernel32 = WinDLL("kernel32", use_last_error=True)
shcore = WinDLL("shcore", use_last_error=True)

# Set DPI awareness for accurate screen capture
shcore.SetProcessDpiAwareness(2)

# Get screen dimensions
WIDTH, HEIGHT = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)

def exit_program():
    """Exit the program gracefully."""
    try:
        sys.exit()
    except SystemExit:
        pass

class TriggerBot:
    def __init__(self):
        # Load the configuration file
        self.load_config()

        # Initialize screen capture tool
        self.sct = mss()

        # State variables
        self.triggerbot_enabled = False
        self.exit_program = False

        # Lock for thread-safe toggling
        self.toggle_lock = threading.Lock()

        # Start the hotkey listener in a separate thread
        threading.Thread(target=self.hotkey_listener, daemon=True).start()

    def load_config(self):
        """Load configuration from a JSON file."""
        try:
            with open('config.json') as json_file:
                config = json.load(json_file)
            self.trigger_hotkey = int(config["trigger_hotkey"], 16)
            self.always_enabled = config["always_enabled"]
            self.trigger_delay = config["trigger_delay"]
            self.base_delay = config["base_delay"]
            self.color_tolerance = config["color_tolerance"]
            self.target_color = tuple(config.get("target_color", DEFAULT_COLOR))
            self.zone_radius = config.get("zone_radius", 2.5)
            self.enable_sounds = config.get("enable_sounds", True)
            self.activation_beep_freq = config.get("activation_beep_freq", 700)
            self.deactivation_beep_freq = config.get("deactivation_beep_freq", 200)
            self.beep_duration = config.get("beep_duration", 100)
            self.randomize_delay = config.get("randomize_delay", False)

            # Define the area to capture (center of the screen)
            self.grab_zone = (
                int(WIDTH / 2 - self.zone_radius),
                int(HEIGHT / 2 - self.zone_radius),
                int(WIDTH / 2 + self.zone_radius),
                int(HEIGHT / 2 + self.zone_radius),
            )
        except (json.JSONDecodeError, KeyError, ValueError) as e:
            print(f"Error loading config: {e}")
            exit_program()

    def toggle_triggerbot(self):
        """Toggle the triggerbot on/off and handle cooldown."""
        with self.toggle_lock:
            self.triggerbot_enabled = not self.triggerbot_enabled
            if self.triggerbot_enabled:
                print("Triggerbot activated.")
                if self.enable_sounds:
                    kernel32.Beep(440, self.beep_duration)
                    kernel32.Beep(self.activation_beep_freq, self.beep_duration)
            else:
                print("Triggerbot deactivated.")
                if self.enable_sounds:
                    kernel32.Beep(440, self.beep_duration)
                    kernel32.Beep(self.deactivation_beep_freq, self.beep_duration)
            time.sleep(COOLDOWN_TIME)  # Sleep directly instead of threading for simplicity

    def hotkey_listener(self):
        """Listen for hotkey presses in a separate thread."""
        while not self.exit_program:
            if keyboard.is_pressed(TOGGLE_HOTKEY):
                self.toggle_triggerbot()

            if keyboard.is_pressed(EXIT_HOTKEY):
                self.exit_program = True
                exit_program()

            time.sleep(0.05)  # Prevent CPU hogging with a small delay

    def process_frame(self):
        """Capture the screen and process the image to detect the target color."""
        img = np.array(self.sct.grab(self.grab_zone))
        pixels = img[:, :, :3].reshape(-1, 3)  # Ignore the alpha channel and flatten image

        # Create a color mask based on the target color and tolerance
        lower_bounds = np.array(self.target_color) - self.color_tolerance
        upper_bounds = np.array(self.target_color) + self.color_tolerance
        color_mask = np.all((pixels >= lower_bounds) & (pixels <= upper_bounds), axis=1)

        if self.triggerbot_enabled and np.any(color_mask):
            delay = self.base_delay * (1 + self.trigger_delay / 100.0)
            if self.randomize_delay:
                delay += np.random.uniform(-self.base_delay * 0.1, self.base_delay * 0.1)  # Randomize delay slightly
            time.sleep(delay)
            keyboard.press_and_release("k")

    def run(self):
        """Main loop to run the triggerbot."""
        while not self.exit_program:
            if self.always_enabled:
                self.process_frame() if self.triggerbot_enabled else time.sleep(0.1)
            else:
                self.run_manual_mode()

    def run_manual_mode(self):
        """Manual mode where the triggerbot is activated only when the hotkey is pressed."""
        while not self.exit_program:
            if win32api.GetAsyncKeyState(self.trigger_hotkey) < 0:
                self.triggerbot_enabled = True
                self.process_frame()
            else:
                time.sleep(0.1)

if __name__ == "__main__":
    TriggerBot().run()